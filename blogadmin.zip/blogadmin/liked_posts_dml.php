<?php
    include ("libs/db_connect.php");
    // get user_id
    $userid = getLoggedMemberID(); //good

	// add to liked posts
	$postid = "";
	
	if(isset($_POST['like'])){
	    $postid = intval($_POST['like']);
	    
	    $liked_post_query = mysqli_query($con, "SELECT * FROM `liked_posts` WHERE user_id ='$userid' AND post_id = $postid");
	    
	    
	    //echo(mysqli_num_rows($liked_post_query));
	    
	    // if the user already liked, unlike -> delete from query
	    if (mysqli_num_rows($liked_post_query) > 0){
	        mysqli_query($con, "DELETE FROM liked_posts WHERE post_id=$postid AND user_id='$userid'");
	        echo "<script type='text/javascript'>alert('Post id# $postid has been removed from your !ikes.');</script>";
	    }
	    
	    // if not liked, add to likes
	    else {
	        mysqli_query($con, "INSERT INTO liked_posts (user_id, post_id) VALUES ('$userid', $postid) ");
	        echo "<script type='text/javascript'>alert('Post id# $postid has been added to your !ikes :)');</script>";
	    }
	}

?>