<?php if(!isset($Translation)){ @header('Location: index.php'); exit; } ?>
  <?php include_once("{$currDir}/header-user.php"); ?>
  <?php include_once("libs/db_connect.php"); ?>
  <?php @include("{$currDir}/hooks/links-home.php"); ?>
  <?php
    //get editor's choice 
    $editor_query = mysqli_query($con, "SELECT * FROM editors_choice");
    $editor_arr = array();
    
	while( $row = mysqli_fetch_assoc($editor_query)){
        $editor_arr[] = $row['blog']; 
    }
    
	$ids = join(',',$editor_arr);  
	$editors_choice = mysqli_query($con, "SELECT * FROM blogs WHERE id IN ($ids)");
	
	//get all recently published posts
	$recent_posts = mysqli_query($con, "SELECT * FROM blogs ORDER BY id DESC LIMIT 4");
	
	//get the latest 3 posts from the admin
	$user = getLoggedMemberId();
	$admin_posts = mysqli_query($con, "SELECT * FROM blogs WHERE author='$user' ORDER BY id DESC LIMIT 3");
	
 
  ?>
<!DOCTYPE html>
<html>
<head>
	  <title>UN!IKE | DASHBOARD </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800'><link rel="stylesheet" href="css/dashboard_style.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.9.0/css/all.css">

   <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src="js/google_api.js"></script>
    <script src="js/weather.js"></script>
     
</head>

<!--cards-->
 <!-- partial:index.partial.html -->
<!-- Dashboard (Parent Block)-->
<div class="dashboard">
  <!-- Dashboard Sidebar (Block)-->
  <div class="dashboard-sidebar">
    <!-- Brand (Element)-->
    <div class="dashboard-sidebar__brand">un!ike</div>
    <!-- Dashboard Nav (Block)-->
    <div class="dashboard-nav">
      <ul>
        <!-- Item (Element)-->
        <li class="dashboard-nav__item dashboard-nav__item--selected"><a href="main.php"><i class="fas fa-home" style = "margin-right:25px;"></i>home</a></li>
        <!-- Item:Selected (Element:Modifier)        -->
        <li class="dashboard-nav__item "><a href="profile_page.php?userid=<?php echo getLoggedMemberID() ?>"><i class="far fa-file"  style = "margin-right:25px;"></i>my page</a></li>
        <!-- Item:Selected (Element:Modifier)        -->
        <li class="dashboard-nav__item"><a href="liked_posts_view.php?userid=<?php echo getLoggedMemberID() ?>"><i class="fas fa-exclamation" style = "margin-right:25px;"></i>!ikes</a></li>
        <!-- Item (Element)-->
        <li class="dashboard-nav__item"><a href="blogs_view.php"><i class="far fa-map" style = "margin-right:25px;"></i>discover </a></li>
        <!-- Item (Element)-->
        <li class="dashboard-nav__item"><a href="<?php echo PREPEND_PATH; ?>membership_profile.php"><i class="fas fa-cog" style = "margin-right:25px;"></i>settings</a></li>
      </ul>
    </div>
  </div>
  <!-- Dashboard Content (Block)-->
  <div class="dashboard-content">
    <!-- Dashboard Header (Block)-->
    <div class="dashboard-header">

      <!-- New (Element)-->
  
    </div>

    <!-- Dashboard Content Panel (Element)-->
    <div class="dashboard-content__panel dashboard-content__panel--active" data-panel-id="home">
      <!-- Dashboard List (Block) -->
      <div class="dashboard-list">
        <!-- Dasboard List Item (Element)-->
        <?php while ($admin_rows = mysqli_fetch_array($admin_posts)) {?>
        <div class="dashboard-list__item" data-item-id="kulon_progo">
          <!-- Title (Element)-->
          <h2><a href = "blogs_view.php?SelectedID=<?php echo $admin_rows['id']?>" style = "color:inherit;"><?php echo $admin_rows['title']?></a></h2>
          <!-- Date (Element)--><span><?php echo $admin_rows['date']?></span>
          <span><?php echo $admin_rows['posted']."ed"?></span>
        </div>
        <?php }?>
      </div>
    </div>
    <!-- Dashboard Content Panel (Element)-->
    <div class="dashboard-content__panel" data-panel-id="settings">
      <p>Settings</p>
    </div>
  </div>
  <!-- Dashboard Preview (Block)  -->
  <div class="dashboard-preview">
    <!-- Panel (Element)-->
    <div class="dashboard-preview__panel dashboard-preview__panel--active" data-panel-id="bromo">
      <!-- Header (Element)-->

        <div class="weather-wrapper">
         <div class="weather-card madrid"> 
         <img id="weather-icon" class = "weather_pic">
        <h1 id = "city_temp_weather"></h1>
        <div id = "city_name_weather" class = "city_name"></div>
        <div id = "city_weather_details" class = "details"></div>
    </div>
    </div>


      <!-- Content (Element)-->
      <div class="dashboard-preview__content">
        <section>
          <h2 style = "font-size:13px;text-decoration:underline;">Recently Published</h2>
          <?php while ($recent_rows = mysqli_fetch_array($recent_posts)) { ?>
          <label>
            <a href="blogs_view.php#<?php echo $recent_rows['id']?>" style = "color:inherit;"><span><?php echo $recent_rows['title']?></span></a>
          </label>
          <?php } ?>
        </section>
        <section>
          <h2 style = "font-size:13px;text-decoration:underline;">Editor's Choice</h2>
          <?php while ($rows = mysqli_fetch_array($editors_choice)) {?>
          <label>
            <a href="blogs_view.php#<?php echo $rows['id']?>" style = "color:inherit;"><span><?php echo $rows['title']?></span></a>
          </label>
          <?php }?>
        </section>
      </div>
    </div>
  </div>

<!-- partial -->
  </div>

    <div class="footer" style = "position:relative;right:0;left: 0;bottom: 0;width: 100%;color: white;text-align: center;padding:2rem;">
<p>un!ike&copy</p>
</div>
    </div><!-- /#wrapper -->
  </body>
</html>

