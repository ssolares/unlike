 <div class="row">
          <div class="col-lg-3">
            <div class="panel panel-warning">
              <div class="panel-heading" style = "background-image: linear-gradient(to right, #74ebd5 0%, #9face6 100%);


">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-info-circle fa-5x" style = "color:white;"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading" style = "color:white;"><?php admincounter("titles");?></p>
                    <p class="announcement-text" style = "color:white;"><strong>Web Details</strong></p>
                  </div>
                </div>
              </div>
              <a href="titles_view.php">
                <div class="panel-footer announcement-bottom" style = "color:#36414f;">
                  <div class="row">
                    <div class="col-xs-6">
                      View
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right" style = "color:#36414f;"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-success">
              <div class="panel-heading" style = "background-image: linear-gradient(120deg, #e0c3fc 0%, #8ec5fc 100%);">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-external-link-square fa-5x" style = "color:white;"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading" style = "color:white;"><?php admincounter("links");?></p>
                    <p class="announcement-text" style = "color:white;"><strong>Links</strong></p>
                  </div>
                </div>
              </div>
              <a href="links_view.php">
                <div class="panel-footer announcement-bottom" style = "color:#36414f;">
                  <div class="row">
                    <div class="col-xs-6">
                      View
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right" style = "color:#36414f;"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-info">
              <div class="panel-heading" style = "background-image: linear-gradient(60deg, #64b3f4 0%, #c2e59c 100%);">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-trophy fa-5x" style = "color:white;"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading" style = "color:white;"><?php admincounter("editors_choice");?></p>
                    <p class="announcement-text" style = "color:white;"><strong>Editor's Picks</strong></p>
                  </div>
                </div>
              </div>
              <a href="editors_choice_view.php">
                <div class="panel-footer announcement-bottom" style = "color:#36414f;">
                  <div class="row">
                    <div class="col-xs-6">
                      View
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right" style = "color:#36414f;"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-primary" style = "border:none;">
              <div class="panel-heading" style = "background-image: linear-gradient(to right, #ff758c 0%, #ff7eb3 100%);">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-bar-chart-o fa-5x" style = "color:white;"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading" style = "color:white;"><?php adminstats("visitor_info","page_hits");?></p>
                    <p class="announcement-text" style = "color:white;"><strong>Admin Stats</strong></p>
                  </div>
                </div>
              </div>
              <a href="../adminstats">
                <div class="panel-footer announcement-bottom" style = "color:#36414f;">
                  <div class="row">
                    <div class="col-xs-6">
                      View
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right" style = "color:#36414f;"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div><!-- /.row -->