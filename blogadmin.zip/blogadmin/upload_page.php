<html>
<head>
<title>UN!IKE | up!oad </title>
<link rel="stylesheet" href="css/upload_img_style.css" />
<link href='https://fonts.googleapis.com/css?family=Roboto+Condensed|Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/upload_img.js"></script>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.8.2/css/all.css'>
<link rel='stylesheet' href='https://unicons.iconscout.com/release/v2.0.1/css/unicons.css'>
</head>
<body>
<nav id="navbar">
    <div class="nav-left">
            <a href="main.php" style = "text-decoration:none;"><span style = "color:#fff;font-weight:500;font-size:20px;">un!ike</span></a>
            <span></span>
            <span></span>
            <span></span>

    </div>
    <div class="nav-right">
        <ul id="navbar-items" >
            <li class="navbar-item"><a class="navbar-item-inner" href="javascript:history.back(1)"><span style = "font-size:12px;"><i class='uil uil-home-alt'></i> return</span></a></li>
            <li class="navbar-item"><a class="navbar-item-inner" href="main.php"><span style = "font-size:12px;"><i class='uil uil-home-alt'></i> dashboard</span></a></li>
            <li class="navbar-item"><a class="navbar-item-inner" href="blogs_view.php"><span style = "font-size:12px;"><i class='uil uil-comment-image'></i> discover</span></a></li>
        </ul>
    </div>
</nav>
<div class="main">
  <div class="parent">
    <p>
      <em>
        <span>u</span>
        <span>p</span>
        <span>!</span>
        <span>o</span>
        <span>a</span>
        <span>d</span>
      </em>
    </p>
  </div>
<form id="uploadimage" action="uplaod_img.php" method="post" enctype="multipart/form-data">
<div id = "message"></div>
<div id="image_preview"><img id="previewing" src="images/waves.gif" /></div>
<div id="selectImage">
<input type="hidden" name = "imgOpt" id = "imgOpt" value="<?php echo $imgOpt; ?>">
<input type="hidden" name = "user" id = "user" value="<?php echo $user; ?>">
<input type="file" name="file" id="file" required />
<input type="submit" value="up!oad" name = "submit" class="submit" />
</div>
</form>
</div>
</body>
</html>
