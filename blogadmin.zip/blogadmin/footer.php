
			<div class="clearfix"></div>
			<?php if(!$_REQUEST['Embedded']){ ?>
				<div style="height: 70px;" class="hidden-print"></div>
				
			<?php } ?>
    
		</div> <!-- /div class="container" -->
	</form>
		
		<script src="<?php echo PREPEND_PATH; ?>resources/lightbox/js/lightbox.min.js"></script>

<?php include("$currDir/liked_posts_dml.php");?>
	</body>
</html>