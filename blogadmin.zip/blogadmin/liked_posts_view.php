<?php 
	$currDir=dirname(__FILE__);
	include("$currDir/lib.php");
	include("$currDir/liked_posts_dml.php");
	include ("libs/db_connect.php");
	
    // get user_id
    $userid = $_GET['userid'];
	// Retrieve liked posts by the user from the database
	$liked_posts = mysqli_query($con, "SELECT post_id FROM liked_posts WHERE user_id='$userid'");
	$liked_posts_arr = array();
	while( $row = mysqli_fetch_assoc($liked_posts)){
        $liked_posts_arr[] = $row['post_id']; 
    }
	$ids = join(',',$liked_posts_arr);  
	$posts = mysqli_query($con, "SELECT * FROM blogs WHERE id IN ($ids)");
	
	//get profile picture and banner
    $profilePic_query = mysqli_query($con, "SELECT profilePic FROM membership_users WHERE memberID='$userid'");
    $bannerPic_query =  mysqli_query($con, "SELECT bannerPic FROM membership_users WHERE memberID='$userid'");
    
    $ppics_result = array();
    if ($row = mysqli_fetch_assoc($profilePic_query)) {
        $ppics_result['profilePic'] = $row['profilePic'];
    }
    
    $bpics_result = array();
    if ($row = mysqli_fetch_assoc($bannerPic_query)) {
        $bpics_result['bannerPic'] = $row['bannerPic'];
    }
    
    //storing into variables
    $profilePicFile = $ppics_result['profilePic'];
    $bannerPicFile = $bpics_result['bannerPic'];
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>UNLIKE | !ikes</title>
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.8.2/css/all.css'>
  <link rel='stylesheet' href='https://unicons.iconscout.com/release/v2.0.1/css/unicons.css'><link rel="stylesheet" href="css/profile_style.css">
  <link rel="stylesheet" href="css/blogTV_style.css">
  <link href="css/bootstrap.css" rel="stylesheet">
  <!-- Add custom CSS here -->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>
<body>
<nav id="navbar">
    <div class="nav-left">
            <a href="main.php" style = "text-decoration:none;"><span style = "color:#fff;font-weight:700;font-size:20px;">un!ike</span></a>
            <span></span>
            <span></span>
            <span></span>

    </div>
    <div class="nav-right">
        <ul id="navbar-items">
            <li class="navbar-item"><a class="navbar-item-inner" href="main.php"><span><i class='uil uil-home-alt'></i> dashboard</span></a></li>
            <li class="navbar-item"><a class="navbar-item-inner" href="blogs_view.php"><span><i class='uil uil-comment-image'></i> discover</span></a></li>
        </ul>
    </div>
</nav>

<!-- partial:index.partial.html -->
<div class="back-to-top" style="display: block; opacity: 1;">
    <a class="semplice-event" href="#" data-event-type="helper" data-event="scrollToTop" style="opacity: 1;">
        <svg version="1.1" id="Ebene_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="53px" height="20px" viewBox="0 0 53 20" enable-background="new 0 0 53 20" xml:space="preserve">
            <g id="Ebene_3"></g>
            <g><polygon points="43.886,16.221 42.697,17.687 26.5,4.731 10.303,17.688 9.114,16.221 26.5,2.312 	"></polygon></g>
        </svg>
    </a>
</div>
 <form class="forms_form" method="post" action="profile_page.php">
<main id="main" class="noheader">
    <div class="user-header-wrapper">
        <div class="user-icon-wrapper shadow">
          <div class="wrap">
            <a href="upload_img.php?img=profile?user=<?php echo $userid?>" class="clip-each clip-border" style = "background: url('images/<?php echo $profilePicFile?>');background-repeat:no-repeat;background-size:cover;">


           <!-- /clip-block -->
          </a>

            <svg class="clip-svg">
              <defs>
                <clipPath id="hexagon-clip" clipPathUnits="objectBoundingBox">
                  <polygon points="0.25 0.05, 0.75 0.05, 1 0.5, 0.75 0.95, 0.25 0.95, 0 0.5" />
                </clipPath>
              </defs>
            </svg>
          </div> <!-- /wrap -->
        </div>
        <div class="user-header-inner" onclick="launchUploadPage()" style = "background: url('images/<?php echo $bannerPicFile?>')">
            <div class="user-header-overlay"></div>
            <img class="user-header" >
        </div>
    </div>
    <div class="user-info">
        <div class="user-info-inner">
            <div class="username-wrapper">
                <div class="verified"><p>Verified Account</p></div>
                <h3 class="username" style = "font-size:40px;"><?php echo $userid ?> </h3>
                <svg class="uname-verified" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1350.03 1326.16">
                    <defs><style>.cls-11{fill:var(--primary);}.cls-12{fill:#ffffff;}</style></defs><title>verified</title>
                    <g id="Layer_3" data-name="Layer 3">
                    <polygon class="cls-11" points="0 747.37 120.83 569.85 70.11 355.04 283.43 292.38 307.3 107.41 554.93 107.41 693.66 0 862.23 120.83 1072.57 126.8 1112.84 319.23 1293.35 399.79 1256.05 614.6 1350.03 793.61 1197.87 941.29 1202.35 1147.15 969.64 1178.48 868.2 1326.16 675.02 1235.17 493.77 1315.72 354.99 1133.73 165.58 1123.29 152.16 878.64 0 747.37"/></g>
                    <g id="Layer_2" data-name="Layer 2">
                    <path class="cls-12" d="M755.33,979.23s125.85,78.43,165.06,114c34.93-36,234.37-277.22,308.24-331.94,54.71,21.89,85,73.4,93,80.25-3.64,21.89-321.91,418.58-368.42,445.94-32.74-3.84-259-195.16-275.4-217C689.67,1049.45,725.24,1003.85,755.33,979.23Z" transform="translate(-322.83 -335.95)"/></g>
                </svg>
            </div>
            <p></p>
            <div class="user-info-bar">
                
                <div class="ufobar-1 ufobar">
                    <a href = "profile_page.php?userid=<?php echo $userid?>" style = "text-decoration:none;width:100%;"><p><i class='uil uil-comment-alt-lines'></i> posts <span><?php echo $numPosts?></span></p></a>
                </div>
                <div class = "ufobar-2 ufobar"  style = "background-color:var(--primary);">
                    <a href = "liked_posts_view.php?userid=<?php echo $userid?>" style = "text-decoration:none;width:100%;"><p><i class='fa fa-exclamation'></i> !ikes <span><?php echo $numLikes?></span></p></a>
                </div>
            </div>
            
        </div>
    </div>
  
  
  	<!-- display posts gotten from the database  -->
	<?php while ($rows = mysqli_fetch_array($posts)) {?>
			<!--use template for blogs_template_TV but with access from array  -->
        
            <!-- Article -->
    
        <section class = "blogTV_section">
            <header class = "blogTV_header" style = "padding-top:0px;">
               <a href = "blogs_view.php?SelectedID=<?php echo $rows['id']?>" style = "text-decoration:none!important;"><h2 class = "blog_title" style = "font-size:25px!important;font-weight:900;line-height:2;"><?php echo $rows['title']?></h2></a>
        <hr class = "div_title">
            <h3 class = "blog_date" style = "font-size:15px;!important"><?php echo $rows['date']?></h3>
             <a href="images/<?php echo $rows['photo']?>" ><img class = "content_pic" src="images/<?php echo $rows['photo']?>" id="photo-image"  ></a>
    

    
        <figure class="profile_pic">
         <img class= "pic" src="http://placekitten.com/g/50/50">
         <figcaption>
         <?php echo $rows['author']?>
        </figcaption>

         </figure>

        </header>
        <article class = "blog_content">
         <p class = "blog_text">
             <a href = "blogs_view.php?SelectedID=<?php echo $rows['id']?>" style = "text-decoration:none!important;color:inherit;"><?php echo $rows['content']?></a>
            </p>
        
        </a>
        </article>
              <a class="like_sym">
        <input type = "submit" name = "like" value = "<%%VALUE(id)%%>" style = "width: 30px;
  height: 30px;
  color: #232526;
  border-radius: 50%;
  font-size:0;
  border: 1px solid #3c1361;
  background: radial-gradient(ellipse at center, #232526, #3c1361);
  box-shadow: 0 15px 50px #800080, 0 -15px 60px #4B0082, inset 0 2px 2px #4B0082;
  -webkit-transition: all 0.3s ease;"/></a>

        </section>

<?php } ?>
  
  
</main>
</form>
<footer id="footer">

    <div class="footer-inner">
            <div class="footer-text">
                <p>Made with ♥ by un!ike</p>
            </div>
    </div>
</footer>
<!-- partial -->
   <script>
        function launchUploadPage(){
           window.location = 'upload_img.php?img=banner?user=<?php echo $userid?>';
        }
  </script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script><script  src="./script.js"></script>


</body>
</html>

