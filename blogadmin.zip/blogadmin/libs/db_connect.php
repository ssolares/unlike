<?php
$con=mysqli_connect("localhost","id12187618_unlikeco","Il831334","id12187618_unlikeco");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 ?>
